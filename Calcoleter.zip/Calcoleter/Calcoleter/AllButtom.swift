//
//  AllButtom.swift
//  Calcoleter
//
//  Created by ابتهال عبدالعزيز on 23/01/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit
class AllButtom : UIButton {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.cornerRadius = 10
    }
    
    
}
