//
//  Brain.swift
//  Calcoleter
//
//  Created by ابتهال عبدالعزيز on 23/01/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import Foundation
class Brain{
    typealias CalcElament = (Num : Double , Op : Character )
    var NumWithOp : [CalcElament] = []
    
    
    func Add (Number : Double , Opration : Character){
        
        NumWithOp.append(CalcElament (Num : Number ,Op : Opration))
        
    }
    
        func Restart () { NumWithOp = [] }
        
        func CalculateMultiplyAndDevidedby(){
            for (index , one )in NumWithOp.enumerated(){
                if one.Op == "×" || one.Op == "÷" {
                    let AffterCurrent = NumWithOp[index + 1]
                    var result : CalcElament!
                    if one.Op == "×"  {
                        result = CalcElament (Num:(one.Num * AffterCurrent.Num),Op:AffterCurrent.Op)
                    }
                    else if  one.Op == "÷" {
                        result = CalcElament(Num:(one.Num / AffterCurrent.Num ),Op :AffterCurrent.Op )
                    }
                    NumWithOp.remove(at: index)
                    NumWithOp.remove(at: index)
                    NumWithOp.insert(result, at: index)
                    CalculateMultiplyAndDevidedby()
                    
                }
                
            }
        }
    
    
    func CalculatAllMinsuss(){
        for (index , one )in NumWithOp.enumerated(){
            if one.Op == "-" {
                  let AffterCurrent = NumWithOp[index + 1]
                NumWithOp.remove(at: index)
                NumWithOp.remove(at: index)
                NumWithOp.insert(CalcElament(Num:(one.Num - AffterCurrent.Num ),Op : "+"), at: index)
                CalculatAllMinsuss()
            }
    }
    
}
    func Result ()-> String{
        CalculatAllMinsuss()
        CalculateMultiplyAndDevidedby()
        var Sum : Double = 0
        for one in NumWithOp {
            Sum = one.Num + Sum}
        let lastResult = String(Sum)
        var Sep = lastResult.components(separatedBy: ".")
        let SecoundPart = Sep [1]
        if SecoundPart == "0"{
            return String(Int(Sum))
        }
        else {
            return String(Sum)
        }
        
    }

}

