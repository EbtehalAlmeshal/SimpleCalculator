//
//  ViewController.swift
//  Calcoleter
//
//  Created by ابتهال عبدالعزيز on 23/01/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let brain : Brain = Brain ()
    
    @IBOutlet weak var ResultLabel: UILabel!
    
    @IBAction func AllButtom ( _ sender : AllButtom){
        let ButtomNumber : String = sender.titleLabel!.text!
        var ResultNumber : String  = ResultLabel.text!
        if ResultNumber == "0"{
            ResultNumber = ""
        }
        ResultLabel.text = ResultNumber + ButtomNumber
        
        
        
        
    }
    
    @IBAction func OprationPressed (_ sender : AllButtom){
        let Opration : Character = Character(sender.titleLabel!.text!)
        let ResultNumber : Double = Double(ResultLabel.text!)!
        brain.Add(Number: ResultNumber, Opration: Opration)
        ResultLabel.text = "0"
        if sender.titleLabel?.text == "="{
            ResultLabel.text = brain.Result()
            brain.Restart()
            
        }
        
        
    }
    @IBAction func Clear(_ sender: Any) {
        MSBox.show(text: " سوف يتم حذف البيانات السابقه", complation: {
            self.ResultLabel.text = "0"
            self.brain.Restart() }, Nocomplation: {
                
        }
        )
      
        
    }
    
    @IBAction func Dotbuttom(_ sender: AllButtom) {
        let ResultNumber : String  = ResultLabel.text!
        for one in ResultNumber {
            if one == "."{
                return }
        }
        
        ResultLabel.text = ResultNumber + "."
        
    }
    
    @IBAction func Backspae(_ sender: AllButtom ) {
        let ResultNumber : String  = ResultLabel.text!
        let TheArray = ResultNumber.dropLast()
        var ResultString = " "
        for one in TheArray {
            ResultString = ResultString + String(one)
            ResultLabel.text = ResultString
            if ResultLabel.text == " " {
                ResultLabel.text = "0"
            }
        }
    }
    
    
    
    @IBAction func PIAction(_ sender: Any) {
        ResultLabel.text = "3.14"
    }
    
    @IBAction func ContactUs (sender : UIButton){
      //  let massege  = " تواصل معنا ع الايميل "
      //  let massegbox = UIAlertController(title: "تواصل معنا", message: massege, preferredStyle:.alert)
      //  let OKbutton : UIAlertAction = UIAlertAction(title: "ok", style:.default, handler: nil)
      //  massegbox.addAction(OKbutton)
      //  let NObutton : UIAlertAction = UIAlertAction(title: "NO", style:.destructive, handler: nil)
       //   massegbox.addAction(NObutton)
       // self.present(massegbox,animated: true,completion: nil)
        // هذا السطر يطلع لي نافذه خاصه يعني اقدر اعدل عليها متى ما بغيت 
        
        MSBox.show(text: "hi there", complation: nil, Nocomplation: nil)
        
        
    }
    
}







