//
//  MessageBox.swift
//  Calcoleter
//
//  Created by ابتهال عبدالعزيز on 12/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit

class MessageBox : UIViewController{
    var Message :  String =  ""
    @IBOutlet weak var Label: UILabel!
    
    override func viewDidLoad() {
        // هنا ياخذ الرساله و يحطها بالليبل يعني الرساله اقدر اغيرها باي مكان
        Label.text = Message
    }
    
    @IBAction func OkyButton (sender : UIButton){
     
// هنا اقدر اطلع من النافذه بدون ذا السطر بصير ناشبه فيها
        Action?()
        dismiss(animated: true, completion: nil)
        
        
    }
    @IBAction func NoButton (sender : UIButton){
        
        // هنا اقدر اطلع من النافذه بدون ذا السطر بصير ناشبه فيها
        NoAction?()
        dismiss(animated: true, completion: nil)
        
        
    }
    // هذي فنكشن نوع ابشنال
    var Action : (()->())?
    var NoAction : (()->())?
    
    
}

class MSBox {
    // هذا نوعه ستاتيك معناته اقد استخدم الميثود باي مكان
    static func show (text : String , complation : (()->())?, Nocomplation :(()->())?){
        
        let StoryBoard = UIStoryboard(name: "MessageBox", bundle: nil)
        var VC = StoryBoard.instantiateViewController(withIdentifier: "MessageBox") as! MessageBox
        VC.Message = text
        VC.modalPresentationStyle = .overCurrentContext
        VC.Action = complation
        VC.NoAction = Nocomplation
        getTopViweController().present(VC, animated: true, completion: nil )
    }
    static func getTopViweController()-> UIViewController{
        
        var viweController  : UIViewController = UIViewController()
        if let vc = UIApplication.shared.delegate?.window??.rootViewController{
            viweController = vc
        }
        return viweController
    }
    
    
}
